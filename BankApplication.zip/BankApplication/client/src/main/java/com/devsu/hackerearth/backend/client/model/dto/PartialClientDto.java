package com.devsu.hackerearth.backend.client.model.dto;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
public class PartialClientDto {

    private Boolean active;

      public Boolean getActive(){
        return active;
      }

      public void setActive(Boolean active){
        this.active=active;
      }


}

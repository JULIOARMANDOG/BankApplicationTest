package com.devsu.hackerearth.backend.client.service.mapper;

import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import java.util.List;
import java.util.stream.Collectors;
public class ClientMapper {

    public static ClientDto toDto(Client client){
        if(client==null){
            return null;
        }
       
        return ClientDto.builder()
        .id(client.getId())
        .dni(client.getDni())
        .name(client.getName())
        .password(client.getPassword())
        .gender(client.getGender())
        .age(client.getAge())
        .address(client.getAddress())
        .phone(client.getPhone())
        .isActive(client.isActive())
        .build();

    }

    public static List<ClientDto> toDtoList(List<Client> clients){
        if(clients==null){
            return List.of();
        }

        return clients.stream()
        .map(ClientMapper::toDto)
        .collect(Collectors.toList());
        
    }


    public static Client toEntityClient(ClientDto clientDto){
        if(clientDto==null){
            return null;
        }
         
        Client client= new Client();
        client.setId(clientDto.getId());
        client.setDni(clientDto.getDni());
        client.setName(clientDto.getName());
        client.setPassword(clientDto.getPassword());
        client.setGender(clientDto.getGender());
        client.setAge(clientDto.getAge());
        client.setAddress(clientDto.getAddress());
        client.setPhone(clientDto.getPhone());
        client.setActive(clientDto.isActive());

        return client;


    }
    
}

package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.client.exception.BadRequestException;
import com.devsu.hackerearth.backend.client.exception.ErrorMessage;
import com.devsu.hackerearth.backend.client.exception.NotFoundException;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;
import com.devsu.hackerearth.backend.client.service.mapper.ClientMapper;



@Service
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;
	private static final Logger log=LoggerFactory.getLogger(ClientServiceImpl.class);
     


	public ClientServiceImpl(ClientRepository clientRepository) {
		this.clientRepository = clientRepository;	
	}

	@Override
	public List<ClientDto> getAll() {
		//Get all clients
		log.info("Start the operation to get all the clients");
        List<Client> clients=clientRepository.findAll();
		List<ClientDto> clientsDto=ClientMapper.toDtoList(clients);
		log.info("End the operation to get all the clients");
		return clientsDto;
	}

	@Override
	public ClientDto getById(Long id) {
		// Get clients by id
		log.info("Start the operation find client by ID");
		if(id==null){
			log.error("client Id can not be null");
			throw new BadRequestException(ErrorMessage.CLIENT_ID_NULL.getMessage());
		}
		
		Client existClient=clientRepository.findById(id)
		.orElseThrow(()-> new NotFoundException(ErrorMessage.CLIENT_NOT_FOUND.getMessage()+id));

		return ClientMapper.toDto(existClient);
	}

	@Override
	public ClientDto create(ClientDto clientDto) {
		log.info("Start the operation create client");
		Client client=ClientMapper.toEntityClient(clientDto);
		if(client==null){
			log.error("Attempt to create client with null data");
			throw new BadRequestException(ErrorMessage.CLIENT_OBJECT_NULL.getMessage());
		}
		client.setActive(clientDto.isActive());
		Client newClient=clientRepository.save(client);
		
		log.info("Client save successfull with ID:{} ", client.getId());
		return ClientMapper.toDto(newClient);
	}

	@Override
	public ClientDto update(ClientDto clientDto) {
		log.info("Start the operation update client");
		if(clientDto==null || clientDto.getId()==null){
			log.error("Attempt to update client with incorrect id data");
			throw new BadRequestException(ErrorMessage.CLIENT_OBJECT_NULL.getMessage());
		}

		Client existClient=clientRepository.findById(clientDto.getId())
		.orElseThrow(()-> new BadRequestException(ErrorMessage.CLIENT_NOT_FOUND.getMessage() + clientDto.getId()));

		existClient.setName(clientDto.getName());
		existClient.setPhone(clientDto.getPhone());
		existClient.setPassword(clientDto.getPassword());
		existClient.setGender(clientDto.getGender());
		existClient.setDni(clientDto.getDni());
		existClient.setAge(clientDto.getAge());
		existClient.setAddress(clientDto.getAddress());
		existClient.setActive(clientDto.isActive());

		Client updateClient=clientRepository.save(existClient);
		
		log.info("Client update successfull with ID:{} ", existClient.getId());
		return ClientMapper.toDto(updateClient);
	}

	@Override
    public ClientDto partialUpdate(Long id, PartialClientDto partialClientDto) {
        // Partial update account
		log.info("Start the operation partial update client");
		if(id==null || partialClientDto==null ){
			log.error("Can not assign Id client with null value");
			throw new BadRequestException(ErrorMessage.CLIENT_ID_NULL.getMessage());
		}

		Client existClient=clientRepository.findById(id)
		.orElseThrow(()-> new BadRequestException(ErrorMessage.CLIENT_NOT_FOUND.getMessage() + id));
         
		existClient.setActive(partialClientDto.getActive());
		Client partialUpdate=clientRepository.save(existClient);
		return ClientMapper.toDto(partialUpdate);
    }

	@Override
	public void deleteById(Long id) {
		// Delete client
		log.info("Start the operation delete client");
		if(id==null ){
			log.error("Can delete a client with Id null");
			throw new BadRequestException(ErrorMessage.CLIENT_ID_NULL.getMessage());
		}

		if(!clientRepository.existsById(id)){
            throw new BadRequestException(ErrorMessage.CLIENT_NOT_FOUND.getMessage()+id);
		}
		
		clientRepository.deleteById(id);
	}
}

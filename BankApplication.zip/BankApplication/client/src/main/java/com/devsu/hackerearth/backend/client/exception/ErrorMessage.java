package com.devsu.hackerearth.backend.client.exception;

public enum ErrorMessage {
    CLIENT_NOT_FOUND("Client not found with id: "),
    CLIENT_OBJECT_NULL("Client object can not be null"),
    CLIENT_ID_NULL("The information client ID can not be null");

    private final String message;
    
    ErrorMessage(String message){
        this.message=message;
    }

    public String getMessage(){
        return message;
    }

    
}

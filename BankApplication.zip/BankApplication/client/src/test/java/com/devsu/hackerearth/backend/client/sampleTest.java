package com.devsu.hackerearth.backend.client;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import com.devsu.hackerearth.backend.client.controller.ClientController;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;
import com.devsu.hackerearth.backend.client.service.ClientService;


@SpringBootTest
@AutoConfigureMockMvc
public class sampleTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ClientRepository clientRepository;

    @BeforeEach
    void setUp(){
        clientRepository.deleteAll();
    }

	private ClientService clientService = mock(ClientService.class);
	private ClientController clientController = new ClientController(clientService);

    @Test
    void createClientTest() {
        // Arrange
        ClientDto newClient = new ClientDto(1L, "Dni", "Name", "Password", "Gender", 1, "Address", "9999999999", true);
        ClientDto createdClient = new ClientDto(1L, "Dni", "Name", "Password", "Gender", 1, "Address", "9999999999", true);
        when(clientService.create(newClient)).thenReturn(createdClient);

        // Act
        ResponseEntity<ClientDto> response = clientController.create(newClient);

        // Assert
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(createdClient, response.getBody());
    }

    @Test
    void updatePartTest(){
        ClientDto clientDto = new ClientDto(1L, "Dni", "Name", "Password", "Gender", 1, "Address", "9999999999", true);
        ClientDto clientDtoPartUpdate = new ClientDto(1L, "Dni", "Name", "Password", "Gender", 1, "Address", "9999999999", false);
        PartialClientDto partialClientDto=new PartialClientDto(Boolean.FALSE);
        when(clientService.partialUpdate(clientDto.getId(), partialClientDto)).thenReturn(clientDtoPartUpdate);
        ResponseEntity<ClientDto> response=clientController.partialUpdate(clientDto.getId(), partialClientDto);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(clientDtoPartUpdate, response.getBody());

    }

    @Test
    void testIntegrationGetClientById() throws Exception{

        Client cliente=new Client();
        cliente.setDni("1713308549");
        cliente.setName("Esteban Rodirguez");
        cliente.setPassword("secreto");
        cliente.setGender("HOMBRE");
        cliente.setAge(35);
        cliente.setAddress("La mañosca");
        cliente.setPhone("0968645702");
        cliente.setActive(true);

        Client clienteGuardado=clientRepository.save(cliente);
        mockMvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get("/api/clients/{id}",clienteGuardado.getId())
        .contentType(MediaType.APPLICATION_JSON))
        .andExpect(org.springframework.test.web.servlet.result.MockMvcResultMatchers.status().isOk())
        .andExpect(org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath("$.id").value(clienteGuardado.getId()))
        .andExpect(org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath("$.name").value("Esteban Rodirguez"));



    }


}

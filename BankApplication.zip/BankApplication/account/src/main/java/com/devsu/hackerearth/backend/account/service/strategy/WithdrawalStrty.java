package com.devsu.hackerearth.backend.account.service.strategy;

import org.springframework.stereotype.Component;

import com.devsu.hackerearth.backend.account.exception.InsufficientAmountException;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;

@Component("WITHDRAWAL")
public class WithdrawalStrty implements ITransactionStrty{
    
    @Override
    public void process(Transaction transaction, Account account){
        if(account.getInitialAmount() < transaction.getAmount()){
           throw new InsufficientAmountException("Saldo no disponible");
        }
        
        account.setInitialAmount(account.getInitialAmount() - transaction.getAmount());
    }
}

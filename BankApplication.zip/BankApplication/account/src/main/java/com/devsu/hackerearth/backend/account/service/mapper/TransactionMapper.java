package com.devsu.hackerearth.backend.account.service.mapper;

import java.util.List;
import java.util.stream.Collectors;

import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;

public class TransactionMapper {

    public static TransactionDto toDto(Transaction transaction){
        if(transaction==null){
            return null;
        }

       return TransactionDto.builder()
                .id(transaction.getId())
                .date(transaction.getDate())
                .type(transaction.getType())
                .amount(transaction.getAmount())
                .balance(transaction.getBalance())
                .accountId(transaction.getAccountId())
                .build();

    }
    
    public static List<TransactionDto> toDtoList(List<Transaction> transactions){

        if(transactions ==null){
            return List.of();
        }

        return transactions.stream()
        .map(TransactionMapper::toDto)
        .collect(Collectors.toList());

    }

    public static Transaction toEntityTransaction(TransactionDto transactionDto){
         
        if(transactionDto==null){
            return null;
        }

        Transaction transaccion= new Transaction();
        transaccion.setId(transactionDto.getId());
        transaccion.setDate(transactionDto.getDate());
        transaccion.setType(transactionDto.getType());
        transaccion.setAmount(transactionDto.getAmount());
        transaccion.setBalance(transactionDto.getAmount());
        transaccion.setAccountId(transactionDto.getAccountId());
        return transaccion;

    }


}

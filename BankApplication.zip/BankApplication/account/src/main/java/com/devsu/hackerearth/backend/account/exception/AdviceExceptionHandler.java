package com.devsu.hackerearth.backend.account.exception;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class AdviceExceptionHandler {
    
@ExceptionHandler(RuntimeException.class)    
public ResponseEntity<Map<String,Object>> handleRuntimeException(RuntimeException ex){
   
    Map<String,Object> errorMap= new HashMap<>();
    errorMap.put("timeestamp", LocalDateTime.now());
    errorMap.put("message", ex.getMessage());
    errorMap.put("status", HttpStatus.INTERNAL_SERVER_ERROR.value());
    return new ResponseEntity<>(errorMap,HttpStatus.INTERNAL_SERVER_ERROR);
}

@ExceptionHandler(BadRequestException.class)
public ResponseEntity<Map<String,Object>> handleBadRequestException(BadRequestException ex){
   
    Map<String,Object> errorMap= new HashMap<>();
    errorMap.put("timeestamp", LocalDateTime.now());
    errorMap.put("message", ex.getMessage());
    errorMap.put("status", HttpStatus.BAD_REQUEST.value());
    return new ResponseEntity<>(errorMap,HttpStatus.BAD_REQUEST);
}


@ExceptionHandler(NotFoundException.class)
public ResponseEntity<Map<String,Object>> handleNotFoundException(NotFoundException ex){
   
    Map<String,Object> errorMap= new HashMap<>();
    errorMap.put("timeestamp", LocalDateTime.now());
    errorMap.put("message", ex.getMessage());
    errorMap.put("status", HttpStatus.NOT_FOUND.value());
    return new ResponseEntity<>(errorMap,HttpStatus.NOT_FOUND);
}

@ExceptionHandler(InsufficientAmountException.class)
public ResponseEntity<Map<String,Object>> handleInsufficientAmountException(InsufficientAmountException ex){
   
    Map<String,Object> errorMap= new HashMap<>();
    errorMap.put("timeestamp", LocalDateTime.now());
    errorMap.put("message", ex.getMessage());
    errorMap.put("status", HttpStatus.NOT_FOUND.value());
    return new ResponseEntity<>(errorMap,HttpStatus.UNPROCESSABLE_ENTITY);
}

}

package com.devsu.hackerearth.backend.account.service.strategy;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;

public interface ITransactionStrty {
    void process(Transaction transaction,Account account);
    
}

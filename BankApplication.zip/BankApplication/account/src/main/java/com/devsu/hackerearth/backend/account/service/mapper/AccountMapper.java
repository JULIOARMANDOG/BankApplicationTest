package com.devsu.hackerearth.backend.account.service.mapper;

import java.util.List;
import java.util.stream.Collectors;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;

public class AccountMapper {

    public static AccountDto toDto(Account account){
        if(account==null){
            return null;
        }

        return AccountDto.builder()
                .id(account.getId())
                .number(account.getNumber())
                .type(account.getType())
                .initialAmount(account.getInitialAmount())
                .isActive(account.isActive())
                .clientId(account.getClientId())
                .build();

    }

    
    public static List<AccountDto> toDtoList(List<Account> accounts){
        if(accounts ==null){
            return List.of();
        }

        return accounts.stream()
        .map(AccountMapper::toDto)
        .collect(Collectors.toList());
    }

    public static Account toEntityAccount(AccountDto accountDto){

        if(accountDto==null){
            return null;
        }

        Account account= new Account();
        account.setId(accountDto.getId());
        account.setNumber(accountDto.getNumber());
        account.setInitialAmount(accountDto.getInitialAmount());
        account.setType(accountDto.getType());
        account.setActive(accountDto.isActive());
        account.setClientId(accountDto.getClientId());
        return account;


    }
    
}

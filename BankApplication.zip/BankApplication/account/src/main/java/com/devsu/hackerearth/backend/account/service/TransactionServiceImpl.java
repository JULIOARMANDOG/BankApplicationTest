package com.devsu.hackerearth.backend.account.service;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.devsu.hackerearth.backend.account.exception.BadRequestException;
import com.devsu.hackerearth.backend.account.exception.ErrorMessage;
import com.devsu.hackerearth.backend.account.exception.NotFoundException;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.ClientDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;
import com.devsu.hackerearth.backend.account.service.mapper.TransactionMapper;
import com.devsu.hackerearth.backend.account.service.strategy.ITransactionStrty;

@Service
public class TransactionServiceImpl implements TransactionService {

    @Value("${client.service.url}")
    private String clientServicePathUrl;

	private final TransactionRepository transactionRepository;
    private final AccountRepository accountRepository;
    private final Map<String,ITransactionStrty>transactionStartegy;
    private final RestTemplate restTemplate;
    
    private static final Logger log=LoggerFactory.getLogger(TransactionServiceImpl.class);

	public TransactionServiceImpl(TransactionRepository transactionRepository,
        AccountRepository accountRepository, Map<String,ITransactionStrty>transactionStartegy,
        RestTemplate restTemplate
    ) {
		this.transactionRepository = transactionRepository;
        this.accountRepository=accountRepository;
        this.transactionStartegy=transactionStartegy;
        this.restTemplate=restTemplate;
	}

    @Override
    public List<TransactionDto> getAll() {
        // Get all transactions
        log.info("Start the operation to get all transaction");
        List<Transaction> transaction=transactionRepository.findAll();
        List<TransactionDto> transactionDtos=TransactionMapper.toDtoList(transaction);
        log.info("End the operation to get all the transaction");
		return transactionDtos;
    }

    @Override
    public TransactionDto getById(Long id) {
        // Get transactions by id
        log.info("Start the operation find transaction by ID");

        if(id==null){
			log.error("transaction Id can not be null");
			throw new BadRequestException(ErrorMessage.TRANSACCION_ID_NULL.getMessage());
		}

		Transaction existTransaction=transactionRepository.findById(id)
		.orElseThrow(()-> new NotFoundException(ErrorMessage.TRANSACTION_NOT_FOUND.getMessage()+id));

		return TransactionMapper.toDto(existTransaction);
    }

    @Override
    public TransactionDto create(TransactionDto transactionDto) {
        // Create transaction
        
		log.info("Start the operation create client");
		Transaction transaction=TransactionMapper.toEntityTransaction(transactionDto);
		if(transaction==null){
			log.error("Attempt to create transaction with null data");
			throw new BadRequestException(ErrorMessage.TRANSACCION_ID_NULL.getMessage());
		}

        Account account=accountRepository.findById(transaction.getAccountId())
        .orElseThrow(()-> new BadRequestException(ErrorMessage.ACCOUNT_NOT_FOUND.getMessage()));
        
        //transaction.getType() debe contener el tipo de transferencia
        //DEPOSIT o WITHDRAWAL
        ITransactionStrty strategy=transactionStartegy.get(transaction.getType());
		if(strategy!=null){
            strategy.process(transaction, account);
            accountRepository.save(account);
        }else{
            throw new BadRequestException(ErrorMessage.TRANSACTION_INVALID_TRANSACTION_TYPE.getMessage());
        }

		Transaction newTransaction=transactionRepository.save(transaction);
		
		log.info("transaction  save successfull with ID:{} ", transaction.getId());
		return TransactionMapper.toDto(newTransaction);
    }

    @Async
    @Override
    public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId, Date dateTransactionStart,
            Date dateTransactionEnd) {
                

                String url=clientServicePathUrl+clientId;
                try{
                    ClientDto clientDto=restTemplate.getForObject(url, ClientDto.class);
                    if(clientDto==null){
                        throw new BadRequestException(ErrorMessage.CLIENT_NOT_FOUND_INFORMATION.getMessage());
                    }
                     
                    List<BankStatementDto> reportBanck= accountRepository.findByClientId(clientId).stream()
                    .flatMap(account -> transactionRepository.findByAccountIdAndDateBetween(
                        account.getId(),
                         dateTransactionStart,
                          dateTransactionEnd).stream()
                        .map(transaction->{
                            BankStatementDto itemBankStatementDto= new BankStatementDto();
                             itemBankStatementDto.setDate(transaction.getDate());
                             itemBankStatementDto.setClient(clientDto.getName());
                             itemBankStatementDto.setAccountNumber(account.getNumber());
                             itemBankStatementDto.setAccountType(account.getType());
                             itemBankStatementDto.setInitialAmount(account.getInitialAmount());
                             itemBankStatementDto.setActive(account.isActive());
                             itemBankStatementDto.setTransactionType(transaction.getType());
                             itemBankStatementDto.setAmount(transaction.getAmount());
                             itemBankStatementDto.setBalance(transaction.getBalance());
                             return itemBankStatementDto;
                        })).collect(Collectors.toList());  

                    return reportBanck;

                }catch(Exception e){
                    throw new BadRequestException(ErrorMessage.CLIENT_NOT_FIND_INFOMRATION.getMessage());
                }
      
    }

    @Override
    public TransactionDto getLastByAccountId(Long accountId) {
        // If you need it
		return null;
    }
    
}

package com.devsu.hackerearth.backend.account.service.strategy;

import org.springframework.stereotype.Component;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;

@Component("DEPOSIT")
public class DepositStrty implements ITransactionStrty {
   
    @Override
    public void process(Transaction transaction,Account account){
       account.setInitialAmount(account.getInitialAmount()+ transaction.getAmount());
    }

}

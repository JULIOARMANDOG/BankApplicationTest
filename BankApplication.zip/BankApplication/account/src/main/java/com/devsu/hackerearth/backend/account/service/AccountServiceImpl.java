package com.devsu.hackerearth.backend.account.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.exception.BadRequestException;
import com.devsu.hackerearth.backend.account.exception.ErrorMessage;
import com.devsu.hackerearth.backend.account.exception.NotFoundException;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.service.mapper.AccountMapper;

@Service
public class AccountServiceImpl implements AccountService {

	private final AccountRepository accountRepository;
    private static final Logger log=LoggerFactory.getLogger(AccountServiceImpl.class);

	public AccountServiceImpl(AccountRepository accountRepository) {
		this.accountRepository = accountRepository;
	}

    @Override
	@NonNull
    public List<AccountDto> getAll() {
        // Get all accounts
        log.info("Start the operation to get all accounts");
        List<Account> accounts=accountRepository.findAll();
        List<AccountDto> accountDtos=AccountMapper.toDtoList(accounts);
		if(accountDtos==null){
			throw new BadRequestException(ErrorMessage.ACCOUNT_NOT_FOUND.getMessage());
		}
        log.info("End the operation to get all the accounts");
		return accountDtos;
    }

    @Override
    public AccountDto getById(Long id) {
        // Get accounts by id
        log.info("Start the operation find account by ID");

        if(id==null){
			log.error("account Id can not be null");
			throw new BadRequestException(ErrorMessage.ACCOUNT_ID_NULL.getMessage());
		}

		Account existAccount=accountRepository.findById(id)
		.orElseThrow(()-> new NotFoundException(ErrorMessage.ACCOUNT_NOT_FOUND.getMessage()+id));

		return AccountMapper.toDto(existAccount);
    }

    @Override
    public AccountDto create(AccountDto accountDto) {
        // Create account
		log.info("Start the operation create client");
		Account account=AccountMapper.toEntityAccount(accountDto);
		if(account==null){
			log.error("Attempt to create client with null data");
			throw new BadRequestException(ErrorMessage.ACCOUNT_ID_NULL.getMessage());
		}
		
		Account newAccount=accountRepository.save(account);
		
		log.info("Client save successfull with ID:{} ", account.getId());
		return AccountMapper.toDto(newAccount);
    }

    @Override
    public AccountDto update(AccountDto accountDto) {
        // Update account
		log.info("Start the operation update account");
		if(accountDto==null || accountDto.getId()==null){
			log.error("Attempt to update account with incorrect id data");
			throw new BadRequestException(ErrorMessage.ACCOUNT_OBJECT_NULL.getMessage());
		}

		Account existAccount=accountRepository.findById(accountDto.getId())
		.orElseThrow(()-> new BadRequestException(ErrorMessage.ACCOUNT_NOT_FOUND.getMessage() + accountDto.getId()));

		existAccount.setNumber(accountDto.getNumber());
		existAccount.setType(accountDto.getType());
		existAccount.setInitialAmount(accountDto.getInitialAmount());
		existAccount.setActive(accountDto.isActive());
		existAccount.setClientId(accountDto.getClientId());
		

		Account updateAccount=accountRepository.save(existAccount);
		
		log.info("Account update successfull with ID:{} ", existAccount.getId());
		return AccountMapper.toDto(updateAccount);

 
    }

    @Override
    public AccountDto partialUpdate(Long id, PartialAccountDto partialAccountDto) {
        // Partial update account
		log.info("Start the operation partial update client");
		if(id==null || partialAccountDto==null ){
			log.error("Can not assign Id account with null value");
			throw new BadRequestException(ErrorMessage.ACCOUNT_ID_NULL.getMessage());
		}

		Account existAcount=accountRepository.findById(id)
		.orElseThrow(()-> new BadRequestException(ErrorMessage.ACCOUNT_NOT_FOUND.getMessage() + id));
         
		existAcount.setActive(partialAccountDto.isActive());
		Account partialUpdate=accountRepository.save(existAcount);
		return AccountMapper.toDto(partialUpdate);
    }

    @Override
    public void deleteById(Long id) {
        // Delete account
        log.info("Start the operation delete account");
		if(id==null ){
			log.error("Can not delete a account with Id null");
			throw new BadRequestException(ErrorMessage.ACCOUNT_ID_NULL.getMessage());
		}

		if(!accountRepository.existsById(id)){
            throw new BadRequestException(ErrorMessage.ACCOUNT_NOT_FOUND.getMessage()+id);
		}
		
		accountRepository.deleteById(id);

    }
    
}

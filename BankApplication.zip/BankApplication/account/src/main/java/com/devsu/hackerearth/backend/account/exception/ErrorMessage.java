package com.devsu.hackerearth.backend.account.exception;

public enum ErrorMessage {
    
    ACCOUNT_NOT_FOUND("Can not found account with id: "),
    ACCOUNT_OBJECT_NULL("Account object can not be null"),
    ACCOUNT_ID_NULL("The information Account  ID can not be null"),
    TRANSACTION_NOT_FOUND("Can not found account with id: "),
    TRANSACTION_OBJECT_NULL("Account object can not be null"),
    TRANSACTION_INVALID_TRANSACTION_TYPE("Invalid transaction type"),
    TRANSACCION_ID_NULL("The information Account  ID can not be null"),
    CLIENT_NOT_FOUND_INFORMATION("Can not find information client in the external service"),
    CLIENT_NOT_FIND_INFOMRATION("Can not find client information");




    private final String message;
    
    ErrorMessage(String message){
        this.message=message;
    }

    public String getMessage(){
        return message;
    }

}
